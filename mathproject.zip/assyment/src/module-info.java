module assyment {
	requires java.desktop;
}